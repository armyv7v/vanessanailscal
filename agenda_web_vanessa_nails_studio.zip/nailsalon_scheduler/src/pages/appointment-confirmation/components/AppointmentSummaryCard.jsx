import React from 'react';
import Icon from '../../../components/AppIcon';

const AppointmentSummaryCard = ({ 
  appointment,
  className = '' 
}) => {
  const formatPrice = (price) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(price);
  };

  const formatDate = (date) => {
    return date?.toLocaleDateString('es-ES', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (time) => {
    return time?.toLocaleTimeString('es-ES', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });
  };

  const formatDuration = (minutes) => {
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}min` : `${hours}h`;
  };

  const totalDuration = appointment?.services?.reduce((sum, service) => sum + (service?.duration || 0), 0);
  const endTime = new Date(appointment?.dateTime?.getTime() + totalDuration * 60000);

  return (
    <div className={`bg-card border border-border rounded-lg overflow-hidden shadow-warm ${className}`}>
      {/* Header */}
      <div className="bg-success/5 border-b border-border p-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-foreground">
              Cita confirmada
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              Código de confirmación: {appointment?.confirmationCode}
            </p>
          </div>
          <div className="bg-success text-success-foreground p-2 rounded-full">
            <Icon name="CheckCircle" size={24} />
          </div>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Date and Time */}
        <div className="flex items-start space-x-3">
          <div className="bg-primary/10 p-2 rounded-lg">
            <Icon name="Calendar" size={20} className="text-primary" />
          </div>
          <div>
            <h4 className="font-semibold text-foreground mb-1">Fecha y hora</h4>
            <p className="text-foreground font-medium">
              {formatDate(appointment?.dateTime)}
            </p>
            <p className="text-muted-foreground">
              {formatTime(appointment?.dateTime)} - {formatTime(endTime)}
            </p>
            <p className="text-sm text-muted-foreground">
              Duración total: {formatDuration(totalDuration)}
            </p>
          </div>
        </div>

        {/* Services */}
        <div className="flex items-start space-x-3">
          <div className="bg-primary/10 p-2 rounded-lg">
            <Icon name="Scissors" size={20} className="text-primary" />
          </div>
          <div className="flex-1">
            <h4 className="font-semibold text-foreground mb-2">
              Servicios ({appointment?.services?.length})
            </h4>
            <div className="space-y-2">
              {appointment?.services?.map((service) => (
                <div key={service?.id} className="flex justify-between items-start">
                  <div>
                    <p className="font-medium text-foreground">{service?.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {formatDuration(service?.duration)}
                    </p>
                  </div>
                  <span className="font-semibold text-foreground">
                    {formatPrice(service?.price)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Customer Info */}
        <div className="flex items-start space-x-3">
          <div className="bg-primary/10 p-2 rounded-lg">
            <Icon name="User" size={20} className="text-primary" />
          </div>
          <div>
            <h4 className="font-semibold text-foreground mb-1">Cliente</h4>
            <p className="text-foreground font-medium">{appointment?.customerInfo?.name}</p>
            <p className="text-muted-foreground text-sm">{appointment?.customerInfo?.email}</p>
            <p className="text-muted-foreground text-sm">{appointment?.customerInfo?.phone}</p>
          </div>
        </div>

        {/* Price Summary */}
        <div className="border-t border-border pt-4">
          <div className="flex items-start space-x-3">
            <div className="bg-primary/10 p-2 rounded-lg">
              <Icon name="CreditCard" size={20} className="text-primary" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-foreground mb-2">Resumen de pago</h4>
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal:</span>
                  <span className="font-medium text-foreground">
                    {formatPrice(appointment?.pricing?.subtotal)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">IVA (19%):</span>
                  <span className="font-medium text-foreground">
                    {formatPrice(appointment?.pricing?.tax)}
                  </span>
                </div>
                <div className="flex justify-between pt-1 border-t border-border">
                  <span className="font-semibold text-foreground">Total:</span>
                  <span className="font-bold text-primary text-lg">
                    {formatPrice(appointment?.pricing?.total)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Status */}
        <div className="flex items-center justify-between bg-success/5 border border-success/20 rounded-lg p-3">
          <div className="flex items-center space-x-2">
            <Icon name="CheckCircle" size={16} className="text-success" />
            <span className="text-sm font-medium text-success">Confirmada</span>
          </div>
          <span className="text-xs text-muted-foreground">
            {new Date()?.toLocaleDateString('es-ES')}
          </span>
        </div>
      </div>
    </div>
  );
};

export default AppointmentSummaryCard;