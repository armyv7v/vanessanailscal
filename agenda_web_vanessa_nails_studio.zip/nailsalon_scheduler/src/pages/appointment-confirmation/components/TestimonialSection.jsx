import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const TestimonialSection = () => {
  const testimonials = [
    {
      id: 1,
      name: "Ana Martínez",
      rating: 5,
      comment: "Excelente servicio y atención. Mis uñas quedaron perfectas y el ambiente es muy relajante. Definitivamente volveré.",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      service: "Manicura Gel"
    },
    {
      id: 2,
      name: "Carmen López",
      rating: 5,
      comment: "El mejor salón de uñas de Madrid. Profesionales, higiénico y con productos de calidad. Lo recomiendo 100%.",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
      service: "Pedicura Spa"
    },
    {
      id: 3,
      name: "Isabel Ruiz",
      rating: 5,
      comment: "Me encanta venir aquí. Siempre salen con ideas nuevas y el resultado es espectacular. Personal muy amable.",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop&crop=face",
      service: "Nail Art"
    }
  ];

  const certifications = [
    {
      name: "Certificación Sanitaria",
      icon: "Shield",
      description: "Cumplimos con todas las normativas de higiene y seguridad"
    },
    {
      name: "Productos Premium",
      icon: "Award",
      description: "Utilizamos solo marcas reconocidas y de alta calidad"
    },
    {
      name: "Profesionales Certificados",
      icon: "Users",
      description: "Nuestro equipo cuenta con formación especializada"
    }
  ];

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Icon
        key={index}
        name="Star"
        size={16}
        className={index < rating ? "text-warning fill-current" : "text-muted-foreground"}
      />
    ));
  };

  return (
    <div className="space-y-8">
      {/* Testimonials */}
      <div className="bg-card border border-border rounded-xl p-6 shadow-warm">
        <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center">
          <Icon name="MessageSquare" size={20} className="mr-2 text-primary" />
          Lo que Dicen Nuestras Clientas
        </h2>
        
        <div className="grid md:grid-cols-3 gap-6">
          {testimonials?.map((testimonial) => (
            <div key={testimonial?.id} className="bg-muted rounded-lg p-4">
              <div className="flex items-center space-x-3 mb-3">
                <div className="w-12 h-12 rounded-full overflow-hidden">
                  <Image
                    src={testimonial?.avatar}
                    alt={testimonial?.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="font-medium text-foreground">{testimonial?.name}</h3>
                  <div className="flex items-center space-x-1">
                    {renderStars(testimonial?.rating)}
                  </div>
                </div>
              </div>
              <p className="text-sm text-muted-foreground mb-2">
                "{testimonial?.comment}"
              </p>
              <div className="text-xs text-primary font-medium">
                Servicio: {testimonial?.service}
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Certifications */}
      <div className="bg-card border border-border rounded-xl p-6 shadow-warm">
        <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center">
          <Icon name="CheckCircle" size={20} className="mr-2 text-primary" />
          Nuestras Garantías
        </h2>
        
        <div className="grid md:grid-cols-3 gap-6">
          {certifications?.map((cert, index) => (
            <div key={index} className="text-center">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-3">
                <Icon name={cert?.icon} size={24} color="white" />
              </div>
              <h3 className="font-medium text-foreground mb-2">{cert?.name}</h3>
              <p className="text-sm text-muted-foreground">{cert?.description}</p>
            </div>
          ))}
        </div>
      </div>
      {/* Salon Gallery */}
      <div className="bg-card border border-border rounded-xl p-6 shadow-warm">
        <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center">
          <Icon name="Camera" size={20} className="mr-2 text-primary" />
          Nuestro Salón
        </h2>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            "https://images.unsplash.com/photo-1560066984-138dadb4c035?w=300&h=200&fit=crop",
            "https://images.unsplash.com/photo-1515377905703-c4788e51af15?w=300&h=200&fit=crop",
            "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=300&h=200&fit=crop",
            "https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?w=300&h=200&fit=crop"
          ]?.map((image, index) => (
            <div key={index} className="aspect-video rounded-lg overflow-hidden">
              <Image
                src={image}
                alt={`Salón imagen ${index + 1}`}
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TestimonialSection;