import React from 'react';
import Icon from '../../../components/AppIcon';

const ConfirmationHeader = () => {
  return (
    <div className="text-center mb-8">
      <div className="w-20 h-20 bg-success rounded-full flex items-center justify-center mx-auto mb-6 shadow-warm-lg">
        <Icon name="Check" size={40} color="white" strokeWidth={3} />
      </div>
      <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-3">
        ¡Reserva Confirmada!
      </h1>
      <p className="text-lg text-muted-foreground max-w-md mx-auto">
        Tu cita ha sido programada exitosamente. Te esperamos en nuestro salón.
      </p>
    </div>
  );
};

export default ConfirmationHeader;