import React from 'react';
import Icon from '../../../components/AppIcon';

const PreparationInstructions = () => {
  const instructions = [
    {
      icon: "Clock",
      title: "Llega 5 minutos antes",
      description: "Te recomendamos llegar unos minutos antes de tu cita para el check-in."
    },
    {
      icon: "Droplets",
      title: "Retira el esmalte anterior",
      description: "Si tienes esmalte previo, retíralo antes de venir o avísanos para incluir este servicio."
    },
    {
      icon: "Hand",
      title: "Cuida tus manos",
      description: "Evita cortar las cutículas en casa 24 horas antes de tu cita."
    },
    {
      icon: "Smartphone",
      title: "Confirma tu asistencia",
      description: "Si necesitas cancelar o reprogramar, avísanos con al menos 2 horas de anticipación."
    }
  ];

  const policies = [
    "Las citas canceladas con menos de 2 horas de anticipación tendrán un cargo del 50%",
    "No se permiten acompañantes en el área de servicios por motivos de higiene",
    "Todos nuestros instrumentos están esterilizados según normativas sanitarias",
    "El pago se realiza al finalizar el servicio (efectivo, tarjeta o transferencia)"
  ];

  return (
    <div className="space-y-6">
      {/* Preparation Instructions */}
      <div className="bg-card border border-border rounded-xl p-6 shadow-warm">
        <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
          <Icon name="Info" size={20} className="mr-2 text-primary" />
          Instrucciones de Preparación
        </h2>
        <div className="grid md:grid-cols-2 gap-4">
          {instructions?.map((instruction, index) => (
            <div key={index} className="flex items-start space-x-3 p-3 bg-muted rounded-lg">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <Icon name={instruction?.icon} size={16} color="white" />
              </div>
              <div>
                <h3 className="font-medium text-foreground mb-1">
                  {instruction?.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {instruction?.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Salon Policies */}
      <div className="bg-card border border-border rounded-xl p-6 shadow-warm">
        <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
          <Icon name="FileText" size={20} className="mr-2 text-primary" />
          Políticas del Salón
        </h2>
        <div className="space-y-3">
          {policies?.map((policy, index) => (
            <div key={index} className="flex items-start space-x-3">
              <Icon name="Check" size={16} className="text-success mt-1 flex-shrink-0" />
              <p className="text-sm text-muted-foreground">
                {policy}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PreparationInstructions;