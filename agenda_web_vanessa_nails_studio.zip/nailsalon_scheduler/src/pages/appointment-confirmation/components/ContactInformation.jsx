import React from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const ContactInformation = () => {
  const contactInfo = {
    phone: "+56991744464",
    whatsapp: "+56991744464",
    email: "info@vanessanails.cl",
    address: "Pasaje Ricardo Videla Pineda 691, Coquimbo",
    hours: {
      weekdays: "Lunes a Viernes: 9:00 - 19:00",
      saturday: "Sábado: 9:00 - 19:00",
      sunday: "Domingo: 9:00 - 19:00"
    }
  };

  const socialLinks = [
    { name: "Instagram", icon: "Instagram", url: "https://instagram.com/vanessanails" },
    { name: "Facebook", icon: "Facebook", url: "https://facebook.com/vanessanails" },
    { name: "TikTok", icon: "Music", url: "https://tiktok.com/@vanessanails" }
  ];

  return (
    <div className="bg-card border border-border rounded-xl p-6 shadow-warm">
      <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center">
        <Icon name="Phone" size={20} className="mr-2 text-primary" />
        Información de Contacto
      </h2>
      <div className="space-y-6">
        {/* Contact Methods */}
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-semibold text-foreground mb-3">
                Para Cambios o Cancelaciones
              </h3>
              <div className="space-y-2">
                <Button
                  variant="outline"
                  onClick={() => window.open(`tel:${contactInfo?.phone}`)}
                  iconName="Phone"
                  iconPosition="left"
                  className="w-full justify-start"
                >
                  {contactInfo?.phone}
                </Button>
                
                <Button
                  variant="outline"
                  onClick={() => window.open(`https://wa.me/${contactInfo?.whatsapp?.replace(/\s/g, '')}`)}
                  iconName="MessageCircle"
                  iconPosition="left"
                  className="w-full justify-start"
                >
                  WhatsApp
                </Button>
                
                <Button
                  variant="outline"
                  onClick={() => window.open(`mailto:${contactInfo?.email}`)}
                  iconName="Mail"
                  iconPosition="left"
                  className="w-full justify-start"
                >
                  {contactInfo?.email}
                </Button>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-semibold text-foreground mb-3">
                Ubicación y Horarios
              </h3>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <Icon name="MapPin" size={16} className="text-primary mt-1 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-foreground">{contactInfo?.address}</p>
                    <Button
                      variant="link"
                      onClick={() => window.open('https://maps.app.goo.gl/YVkqtopj4t5Urdhr9')}
                      className="p-0 h-auto text-xs text-primary"
                    >
                      Ver en Google Maps
                    </Button>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <Icon name="Clock" size={16} className="text-primary mt-1 flex-shrink-0" />
                  <div className="text-sm text-foreground space-y-1">
                    <p>{contactInfo?.hours?.weekdays}</p>
                    <p>{contactInfo?.hours?.saturday}</p>
                    <p className="text-muted-foreground">{contactInfo?.hours?.sunday}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Social Media */}
        <div className="border-t border-border pt-4">
          <h3 className="text-sm font-semibold text-foreground mb-3">
            Síguenos en Redes Sociales
          </h3>
          <div className="flex space-x-3">
            {socialLinks?.map((social, index) => (
              <Button
                key={index}
                variant="ghost"
                size="sm"
                onClick={() => window.open(social?.url, '_blank')}
                iconName={social?.icon}
                className="text-muted-foreground hover:text-primary"
              >
                {social?.name}
              </Button>
            ))}
          </div>
        </div>

        {/* Important Notice */}
        <div className="bg-warning/10 border border-warning/20 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <Icon name="AlertTriangle" size={20} className="text-warning flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-warning mb-1">
                Importante: Política de Cancelación
              </p>
              <p className="text-xs text-warning/80">
                Para cancelar o reprogramar tu cita, contáctanos con al menos 2 horas de anticipación. 
                Las cancelaciones tardías pueden tener un cargo del 50% del servicio.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactInformation;