import React, { useState } from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const ActionButtons = ({ appointmentData }) => {
  const [emailSent, setEmailSent] = useState(false);
  const [calendarAdded, setCalendarAdded] = useState(false);

  const {
    appointmentDate = "2025-01-15T14:30:00",
    selectedServices = [
      { name: "Manicura Clásica", duration: 45 },
      { name: "Esmaltado Gel", duration: 30 }
    ],
    totalDuration = 75
  } = appointmentData;

  const handleAddToCalendar = () => {
    const startDate = new Date(appointmentDate);
    const endDate = new Date(startDate.getTime() + totalDuration * 60000);
    
    const formatDate = (date) => {
      return date?.toISOString()?.replace(/[-:]/g, '')?.split('.')?.[0] + 'Z';
    };

    const title = `Cita NailSalon - ${selectedServices?.map(s => s?.name)?.join(', ')}`;
    const details = `Servicios: ${selectedServices?.map(s => s?.name)?.join(', ')}\nDuración: ${totalDuration} minutos\nUbicación: NailSalon Scheduler`;
    const location = "NailSalon Scheduler, Calle Principal 123, Madrid";

    const googleCalendarUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(title)}&dates=${formatDate(startDate)}/${formatDate(endDate)}&details=${encodeURIComponent(details)}&location=${encodeURIComponent(location)}`;

    window.open(googleCalendarUrl, '_blank');
    setCalendarAdded(true);
  };

  const handleSendEmail = () => {
    // Simulate email sending
    setEmailSent(true);
    setTimeout(() => setEmailSent(false), 3000);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Mi cita en NailSalon',
        text: 'He reservado una cita en NailSalon Scheduler',
        url: window.location?.href
      });
    } else {
      // Fallback for browsers that don't support Web Share API
      navigator.clipboard?.writeText(window.location?.href);
      alert('Enlace copiado al portapapeles');
    }
  };

  return (
    <div className="space-y-4">
      {/* Primary Actions */}
      <div className="grid md:grid-cols-2 gap-4">
        <Button
          variant="default"
          onClick={handleAddToCalendar}
          iconName={calendarAdded ? "Check" : "Calendar"}
          iconPosition="left"
          className="w-full"
        >
          {calendarAdded ? 'Añadido al Calendario' : 'Añadir al Calendario'}
        </Button>
        
        <Button
          variant="outline"
          onClick={handleSendEmail}
          iconName={emailSent ? "Check" : "Mail"}
          iconPosition="left"
          className="w-full"
          disabled={emailSent}
        >
          {emailSent ? 'Email Enviado' : 'Enviar por Email'}
        </Button>
      </div>

      {/* Secondary Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Button
          variant="ghost"
          onClick={handlePrint}
          iconName="Printer"
          iconPosition="left"
          size="sm"
          className="w-full"
        >
          Imprimir
        </Button>
        
        <Button
          variant="ghost"
          onClick={handleShare}
          iconName="Share2"
          iconPosition="left"
          size="sm"
          className="w-full"
        >
          Compartir
        </Button>
        
        <Button
          variant="ghost"
          onClick={() => window.open('https://wa.me/34612345678', '_blank')}
          iconName="MessageCircle"
          iconPosition="left"
          size="sm"
          className="w-full"
        >
          WhatsApp
        </Button>
        
        <Button
          variant="ghost"
          onClick={() => window.open('https://maps.google.com/?q=40.4168,-3.7038', '_blank')}
          iconName="MapPin"
          iconPosition="left"
          size="sm"
          className="w-full"
        >
          Ubicación
        </Button>
      </div>

      {/* Google Sheets Confirmation */}
      <div className="bg-success/10 border border-success/20 rounded-lg p-4 mt-6">
        <div className="flex items-center space-x-3">
          <Icon name="Database" size={20} className="text-success" />
          <div>
            <p className="text-sm font-medium text-success">
              Reserva Guardada Automáticamente
            </p>
            <p className="text-xs text-success/80">
              Tu cita ha sido registrada en nuestro sistema de gestión
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ActionButtons;