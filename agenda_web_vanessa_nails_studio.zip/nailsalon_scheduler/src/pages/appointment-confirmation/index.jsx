import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import ConfirmationHeader from './components/ConfirmationHeader';
import AppointmentSummaryCard from './components/AppointmentSummaryCard';
import PreparationInstructions from './components/PreparationInstructions';
import ActionButtons from './components/ActionButtons';
import ContactInformation from './components/ContactInformation';
import TestimonialSection from './components/TestimonialSection';

const AppointmentConfirmation = () => {
  // Mock appointment data - in real app this would come from state/props
  const appointmentData = {
    bookingId: "NS-2025-001",
    selectedServices: [
      {
        id: 1,
        name: "Manicura Clásica",
        duration: 45,
        price: 25.000
      },
      {
        id: 2,
        name: "Esmaltado Gel",
        duration: 30,
        price: 15.000
      }
    ],
    appointmentDate: "2025-01-15T14:30:00",
    customerInfo: {
      name: "María García López",
      phone: "+34 612 345 678",
      email: "maria.garcia@email.com"
    },
    totalDuration: 75,
    totalPrice: 40.000
  };

  useEffect(() => {
    // Scroll to top when component mounts
    window.scrollTo(0, 0);
    
    // Add print styles for better printing experience
    const printStyles = document.createElement('style');
    printStyles.textContent = `
      @media print {
        .no-print { display: none !important; }
        .print-only { display: block !important; }
        body { background: white !important; }
        .bg-card { background: white !important; border: 1px solid #ccc !important; }
      }
    `;
    document.head?.appendChild(printStyles);

    return () => {
      document.head?.removeChild(printStyles);
    };
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Confirmación de Cita - Vanessa Nais Studio </title>
        <meta name="description" content="Tu cita ha sido confirmada exitosamente. Revisa los detalles de tu reserva y prepárate para tu visita al salón." />
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>
      <Header />
      <main className="pt-32 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            {/* Confirmation Header */}
            <ConfirmationHeader />

            {/* Main Content Grid */}
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Left Column - Main Content */}
              <div className="lg:col-span-2 space-y-8">
                {/* Appointment Summary */}
                <AppointmentSummaryCard appointmentData={appointmentData} />

                {/* Action Buttons */}
                <ActionButtons appointmentData={appointmentData} />

                {/* Preparation Instructions */}
                <PreparationInstructions />

                {/* Mobile Contact Info */}
                <div className="lg:hidden">
                  <ContactInformation />
                </div>
              </div>

              {/* Right Column - Sidebar */}
              <div className="lg:col-span-1 space-y-8">
                {/* Desktop Contact Info */}
                <div className="hidden lg:block">
                  <ContactInformation />
                </div>

                {/* Testimonials and Gallery - Desktop Only */}
                <div className="hidden xl:block">
                  <TestimonialSection />
                </div>
              </div>
            </div>

            {/* Full Width Testimonials - Mobile/Tablet */}
            <div className="xl:hidden mt-12">
              <TestimonialSection />
            </div>

            {/* Success Footer */}
            <div className="mt-12 text-center">
              <div className="bg-success/10 border border-success/20 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-success mb-2">
                  ¡Gracias por Elegir Vanessa Nails Studio!
                </h3>
                <p className="text-success/80 max-w-2xl mx-auto">
                  Tu reserva ha sido procesada exitosamente y guardada en nuestro sistema. 
                  Recibirás un recordatorio 24 horas antes de tu cita. ¡Nos vemos pronto!
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      {/* Print-only footer */}
      <div className="print-only hidden">
        <div className="text-center text-sm text-muted-foreground mt-8 border-t pt-4">
          <p>Vanessa Nails Studio - Pasaje Ricardo Videla Pineda 691, Coquimbo</p>
          <p>Tel: +569 917 444 64 | Email: info@nailsalon.es</p>
          <p>Impreso el {new Date()?.toLocaleDateString('es-ES')}</p>
        </div>
      </div>
    </div>
  );
};

export default AppointmentConfirmation;