import React, { useState, useEffect } from 'react';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const CustomerForm = ({ onSubmit, isLoading = false, initialData = {} }) => {
  const [formData, setFormData] = useState({
    fullName: initialData?.fullName || '',
    phone: initialData?.phone || '',
    email: initialData?.email || '',
    notes: initialData?.notes || ''
  });

  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});

  // Validation rules
  const validateField = (name, value) => {
    switch (name) {
      case 'fullName':
        if (!value?.trim()) return 'El nombre completo es obligatorio';
        if (value?.trim()?.length < 2) return 'El nombre debe tener al menos 2 caracteres';
        if (!/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/?.test(value)) return 'El nombre solo puede contener letras';
        return '';

      case 'phone':
        if (!value?.trim()) return 'El número de teléfono es obligatorio';
        const phoneRegex = /^(\+56|930072|631)?[6789]\d{8}$/;
        if (!phoneRegex?.test(value?.replace(/\s/g, ''))) {
          return 'Introduce un número de teléfono válido';
        }
        return '';

      case 'email':
        if (!value?.trim()) return 'El correo electrónico es obligatorio';
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex?.test(value)) return 'Introduce un correo electrónico válido';
        return '';

      case 'notes':
        if (value?.length > 500) return 'Las notas no pueden exceder 500 caracteres';
        return '';

      default:
        return '';
    }
  };

  // Format phone number as user types
  const formatPhoneNumber = (value) => {
    const cleaned = value?.replace(/\D/g, '');
    if (cleaned?.startsWith('56')) {
      const number = cleaned?.substring(2);
      if (number?.length <= 3) return `+56 ${number}`;
      if (number?.length <= 6) return `+56 ${number?.slice(0, 3)} ${number?.slice(3)}`;
      return `+56 ${number?.slice(0, 3)} ${number?.slice(3, 6)} ${number?.slice(6, 9)}`;
    }
    if (cleaned?.length <= 3) return cleaned;
    if (cleaned?.length <= 6) return `${cleaned?.slice(0, 3)} ${cleaned?.slice(3)}`;
    return `${cleaned?.slice(0, 3)} ${cleaned?.slice(3, 6)} ${cleaned?.slice(6, 9)}`;
  };

  const handleInputChange = (e) => {
    const { name, value } = e?.target;
    let formattedValue = value;

    if (name === 'phone') {
      formattedValue = formatPhoneNumber(value);
    }

    setFormData(prev => ({
      ...prev,
      [name]: formattedValue
    }));

    // Real-time validation
    if (touched?.[name]) {
      const error = validateField(name, formattedValue);
      setErrors(prev => ({
        ...prev,
        [name]: error
      }));
    }
  };

  const handleBlur = (e) => {
    const { name, value } = e?.target;
    setTouched(prev => ({
      ...prev,
      [name]: true
    }));

    const error = validateField(name, value);
    setErrors(prev => ({
      ...prev,
      [name]: error
    }));
  };

  const validateForm = () => {
    const newErrors = {};
    Object.keys(formData)?.forEach(key => {
      if (key !== 'notes') { // notes is optional
        const error = validateField(key, formData?.[key]);
        if (error) newErrors[key] = error;
      }
    });
    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleSubmit = (e) => {
    e?.preventDefault();
    setTouched({
      fullName: true,
      phone: true,
      email: true,
      notes: true
    });

    if (validateForm()) {
      onSubmit(formData);
    }
  };

  const isFormValid = () => {
    return formData?.fullName?.trim() && 
           formData?.phone?.trim() && 
           formData?.email?.trim() && 
           Object.values(errors)?.every(error => !error);
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-warm">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-foreground mb-2 flex items-center">
          <Icon name="User" size={24} className="mr-3 text-primary" />
          Información de contacto
        </h2>
        <p className="text-muted-foreground text-sm">
          Completa tus datos para confirmar la cita. Todos los campos marcados con * son obligatorios.
        </p>
      </div>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="md:col-span-2">
            <Input
              label="Nombre completo *"
              type="text"
              name="fullName"
              value={formData?.fullName}
              onChange={handleInputChange}
              onBlur={handleBlur}
              placeholder="Introduce tu nombre completo"
              error={errors?.fullName}
              required
              disabled={isLoading}
              className="w-full"
            />
          </div>

          <div>
            <Input
              label="Número de teléfono *"
              type="tel"
              name="phone"
              value={formData?.phone}
              onChange={handleInputChange}
              onBlur={handleBlur}
              placeholder="900 123 456"
              error={errors?.phone}
              description="Formato: 900 123 456 o +56 900 123 456"
              required
              disabled={isLoading}
              className="w-full"
            />
          </div>

          <div>
            <Input
              label="Correo electrónico *"
              type="email"
              name="email"
              value={formData?.email}
              onChange={handleInputChange}
              onBlur={handleBlur}
              placeholder="tu@email.com"
              error={errors?.email}
              description="Te enviaremos la confirmación de tu cita"
              required
              disabled={isLoading}
              className="w-full"
            />
          </div>

          <div className="md:col-span-2">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Notas adicionales (opcional)
              </label>
              <textarea
                name="notes"
                value={formData?.notes}
                onChange={handleInputChange}
                onBlur={handleBlur}
                placeholder="¿Alguna preferencia especial o comentario sobre tu cita?"
                disabled={isLoading}
                rows={3}
                maxLength={500}
                className="w-full px-3 py-2 border border-border rounded-lg bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-none transition-warm disabled:opacity-50 disabled:cursor-not-allowed"
              />
              <div className="flex justify-between items-center text-xs text-muted-foreground">
                <span>Máximo 500 caracteres</span>
                <span>{formData?.notes?.length}/500</span>
              </div>
              {errors?.notes && (
                <p className="text-error text-xs mt-1 flex items-center">
                  <Icon name="AlertCircle" size={12} className="mr-1" />
                  {errors?.notes}
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Privacy Notice */}
        <div className="bg-muted rounded-lg p-4 border border-border">
          <div className="flex items-start space-x-3">
            <Icon name="Shield" size={20} className="text-primary mt-0.5 flex-shrink-0" />
            <div className="text-sm text-muted-foreground">
              <p className="font-medium text-foreground mb-1">Protección de datos</p>
              <p>
                Tus datos personales se utilizarán únicamente para gestionar tu cita y enviarte 
                confirmaciones. No compartimos tu información con terceros y cumplimos con el RGPD.
              </p>
            </div>
          </div>
        </div>

        {/* Submit Button - Hidden on mobile (handled by NavigationControls) */}
        <div className="hidden md:flex justify-end pt-4">
          <Button
            type="submit"
            variant="default"
            disabled={!isFormValid() || isLoading}
            loading={isLoading}
            iconName="ArrowRight"
            iconPosition="right"
            className="min-w-[160px]"
          >
            Confirmar cita
          </Button>
        </div>
      </form>
    </div>
  );
};

export default CustomerForm;