import React from 'react';
import Icon from '../../../components/AppIcon';

const BookingReview = ({ bookingData = {} }) => {
  const {
    selectedServices = [],
    selectedDateTime = null,
    totalDuration = 0,
    totalPrice = 0,
    location = "Vanessa Nails Studio"
  } = bookingData;

  const formatDateTime = (dateTime) => {
    if (!dateTime) return '';
    const date = new Date(dateTime);
    return {
      date: date?.toLocaleDateString('es-ES', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      }),
      time: date?.toLocaleTimeString('es-ES', {
        hour: '2-digit',
        minute: '2-digit'
      })
    };
  };

  const formatDuration = (minutes) => {
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}min` : `${hours}h`;
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'CLP'
    })?.format(price);
  };

  const dateTime = formatDateTime(selectedDateTime);

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-warm mb-6">
      <div className="mb-4">
        <h2 className="text-lg font-semibold text-foreground mb-2 flex items-center">
          <Icon name="Calendar" size={20} className="mr-2 text-primary" />
          Resumen de tu cita
        </h2>
        <p className="text-sm text-muted-foreground">
          Revisa los detalles de tu reserva antes de confirmar
        </p>
      </div>
      <div className="space-y-4">
        {/* Services */}
        {selectedServices?.length > 0 && (
          <div className="pb-4 border-b border-border">
            <h3 className="text-sm font-medium text-foreground mb-3 flex items-center">
              <Icon name="Sparkles" size={16} className="mr-2 text-primary" />
              Servicios seleccionados
            </h3>
            <div className="space-y-2">
              {selectedServices?.map((service, index) => (
                <div key={index} className="flex justify-between items-center">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">{service?.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatDuration(service?.duration)}
                    </p>
                  </div>
                  <p className="text-sm font-semibold text-foreground ml-4">
                    {formatPrice(service?.price)}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Date and Time */}
        {selectedDateTime && (
          <div className="pb-4 border-b border-border">
            <h3 className="text-sm font-medium text-foreground mb-3 flex items-center">
              <Icon name="Clock" size={16} className="mr-2 text-primary" />
              Fecha y hora
            </h3>
            <div className="bg-muted rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-foreground capitalize">
                    {dateTime?.date}
                  </p>
                  <p className="text-lg font-semibold text-primary">
                    {dateTime?.time}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">Duración total</p>
                  <p className="text-sm font-medium text-foreground">
                    {formatDuration(totalDuration)}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Location */}
        <div className="pb-4 border-b border-border">
          <h3 className="text-sm font-medium text-foreground mb-3 flex items-center">
            <Icon name="MapPin" size={16} className="mr-2 text-primary" />
            Ubicación
          </h3>
          <div className="flex items-start space-x-3">
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">{location}</p>
              <p className="text-xs text-muted-foreground">
                Pasaje Ricardo Videla Pineda 691, Coquimbo
              </p>
            </div>
            <button className="text-primary hover:text-primary/80 transition-warm">
              <Icon name="ExternalLink" size={16} />
            </button>
          </div>
        </div>

        {/* Total */}
        <div className="bg-primary/5 rounded-lg p-4">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-muted-foreground">Total a pagar</p>
              <p className="text-xs text-muted-foreground">
                {selectedServices?.length} servicio{selectedServices?.length !== 1 ? 's' : ''}
              </p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-primary">
                {formatPrice(totalPrice)}
              </p>
              <p className="text-xs text-muted-foreground">
                IVA incluido
              </p>
            </div>
          </div>
        </div>

        {/* Important Notes */}
        <div className="bg-warning/10 border border-warning/20 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <Icon name="Info" size={16} className="text-warning mt-0.5 flex-shrink-0" />
            <div className="text-sm">
              <p className="font-medium text-foreground mb-1">Información importante</p>
              <ul className="text-muted-foreground space-y-1 text-xs">
                <li>• Llega 10 minutos antes de tu cita</li>
                <li>• Cancelaciones gratuitas hasta 24h antes</li>
                <li>• El pago se realiza en el salón</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingReview;