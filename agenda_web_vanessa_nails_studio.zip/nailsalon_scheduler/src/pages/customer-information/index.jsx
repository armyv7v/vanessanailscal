import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import NavigationControls from '../../components/ui/NavigationControls';
import BookingReview from './components/BookingReview';
import CustomerForm from './components/CustomerForm';

const CustomerInformation = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [customerData, setCustomerData] = useState({});

  // Mock booking data - in real app this would come from state management
  const [bookingData] = useState({
    selectedServices: [
      {
        id: 1,
        name: "Manicura clásica",
        duration: 45,
        price: 25.00,
        description: "Limado, cutícula y esmaltado básico"
      },
      {
        id: 2,
        name: "Esmaltado semipermanente",
        duration: 30,
        price: 35.00,
        description: "Duración hasta 3 semanas"
      }
    ],
    selectedDateTime: new Date('2025-01-15T14:30:00'),
    totalDuration: 75,
    totalPrice: 60.00,
    location: "NailSalon Studio"
  });

  useEffect(() => {
    // Scroll to top when component mounts
    window.scrollTo(0, 0);
  }, []);

  const handleFormSubmit = async (formData) => {
    setIsLoading(true);
    
    try {
      // Simulate API call to save customer information
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // In real app, this would save to Google Sheets or backend
      const completeBookingData = {
        ...bookingData,
        customerInfo: formData,
        bookingId: `NS-${Date.now()}`,
        status: 'confirmed',
        createdAt: new Date()?.toISOString()
      };

      console.log('Booking data to save:', completeBookingData);
      
      setCustomerData(formData);
      
      // Navigate to confirmation page
      navigate('/appointment-confirmation', {
        state: { bookingData: completeBookingData }
      });
      
    } catch (error) {
      console.error('Error saving booking:', error);
      // In real app, show error message to user
    } finally {
      setIsLoading(false);
    }
  };

  const handleBack = () => {
    navigate('/time-slot-selection');
  };

  const canProceed = () => {
    return customerData?.fullName && 
           customerData?.phone && 
           customerData?.email;
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-32 pb-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page Header */}
          <div className="text-center mb-8">
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-3">
              Información de contacto
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Solo necesitamos algunos datos para confirmar tu cita. 
              Te enviaremos todos los detalles por email y SMS.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Booking Review - Left Column on Desktop */}
            <div className="lg:col-span-1 order-1 lg:order-1">
              <div className="sticky top-24">
                <BookingReview bookingData={bookingData} />
              </div>
            </div>

            {/* Customer Form - Right Column on Desktop */}
            <div className="lg:col-span-2 order-2 lg:order-2">
              <CustomerForm
                onSubmit={handleFormSubmit}
                isLoading={isLoading}
                initialData={customerData}
              />
            </div>
          </div>
        </div>
      </main>

      <NavigationControls
        onNext={() => handleFormSubmit(customerData)}
        onBack={handleBack}
        nextLabel="Confirmar cita"
        backLabel="Volver a horarios"
        canProceed={canProceed()}
        isLoading={isLoading}
        showBack={true}
      />
    </div>
  );
};

export default CustomerInformation;