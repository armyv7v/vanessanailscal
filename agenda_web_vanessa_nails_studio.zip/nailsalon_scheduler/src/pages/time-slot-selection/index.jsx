import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import NavigationControls from '../../components/ui/NavigationControls';
import ServiceSummaryCard from './components/ServiceSummaryCard';
import DatePicker from './components/DatePicker';
import TimeSlotGrid from './components/TimeSlotGrid';

const TimeSlotSelection = () => {
  const navigate = useNavigate();
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Mock data for selected services (in real app, this would come from state management)
  const [selectedServices] = useState([
    {
      id: 1,
      name: "Manicura clásica",
      duration: 45,
      price: 25.000,
      description: "Limado, cutícula y esmaltado básico"
    },
    {
      id: 2,
      name: "Diseño de uñas",
      duration: 30,
      price: 15.000,
      description: "Arte personalizado en uñas"
    }
  ]);

  // Calculate totals
  const totalDuration = selectedServices?.reduce((sum, service) => sum + service?.duration, 0);
  const totalPrice = selectedServices?.reduce((sum, service) => sum + service?.price, 0);

  // Mock unavailable dates (fully booked days)
  const unavailableDates = [
    new Date(2025, 0, 10), // January 10, 2025
    new Date(2025, 0, 15), // January 15, 2025
    new Date(2025, 0, 22), // January 22, 2025
  ];

  // Mock unavailable time slots for selected date
  const [unavailableSlots] = useState([
    '10:00', '10:30', '14:00', '14:30', '15:00', '16:30', '17:00'
  ]);

  useEffect(() => {
    // Reset selected time when date changes
    if (selectedDate) {
      setSelectedTime(null);
      // Simulate loading time slots
      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
      }, 800);
    }
  }, [selectedDate]);

  // Check if user can proceed to next step
  const canProceed = selectedDate && selectedTime && selectedServices?.length > 0;

  const handleDateSelect = (date) => {
    setSelectedDate(date);
  };

  const handleTimeSelect = (time) => {
    setSelectedTime(time);
  };

  const handleNext = () => {
    if (canProceed) {
      // In real app, save selection to state management
      const bookingData = {
        services: selectedServices,
        date: selectedDate,
        time: selectedTime,
        duration: totalDuration,
        price: totalPrice
      };
      
      // Store in localStorage for demo purposes
      localStorage.setItem('bookingData', JSON.stringify(bookingData));
      
      navigate('/customer-information');
    }
  };

  const handleBack = () => {
    navigate('/service-selection');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-32 pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            {/* Page Header */}
            <div className="text-center mb-8">
              <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
                Selecciona tu horario
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Elige la fecha y hora que mejor se adapte a tu agenda. 
                Los horarios mostrados tienen en cuenta la duración de tus servicios seleccionados.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Main Content */}
              <div className="lg:col-span-2 space-y-6">
                {/* Service Summary */}
                <ServiceSummaryCard 
                  selectedServices={selectedServices}
                  totalDuration={totalDuration}
                  totalPrice={totalPrice}
                />

                {/* Date Picker */}
                <DatePicker 
                  selectedDate={selectedDate}
                  onDateSelect={handleDateSelect}
                  unavailableDates={unavailableDates}
                />

                {/* Time Slot Grid */}
                <TimeSlotGrid 
                  selectedDate={selectedDate}
                  selectedTime={selectedTime}
                  onTimeSelect={handleTimeSelect}
                  serviceDuration={totalDuration}
                  unavailableSlots={unavailableSlots}
                  isLoading={isLoading}
                />
              </div>

              {/* Sidebar - Booking Summary (Desktop) */}
              <div className="hidden lg:block">
                <div className="sticky top-32">
                  <div className="bg-card border border-border rounded-lg p-6 shadow-warm">
                    <h3 className="text-lg font-semibold text-foreground mb-4">
                      Resumen de tu cita
                    </h3>
                    
                    {selectedDate && (
                      <div className="mb-4 pb-4 border-b border-border">
                        <p className="text-sm text-muted-foreground mb-1">Fecha:</p>
                        <p className="font-medium text-foreground capitalize">
                          {selectedDate?.toLocaleDateString('es-ES', {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          })}
                        </p>
                      </div>
                    )}

                    {selectedTime && (
                      <div className="mb-4 pb-4 border-b border-border">
                        <p className="text-sm text-muted-foreground mb-1">Hora:</p>
                        <p className="font-medium text-foreground">
                          {selectedTime?.toLocaleTimeString('es-ES', {
                            hour: '2-digit',
                            minute: '2-digit',
                            hour12: false
                          })} - {new Date(selectedTime.getTime() + totalDuration * 60000)?.toLocaleTimeString('es-ES', {
                            hour: '2-digit',
                            minute: '2-digit',
                            hour12: false
                          })}
                        </p>
                      </div>
                    )}

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Servicios:</span>
                        <span className="text-foreground">{selectedServices?.length}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Duración:</span>
                        <span className="text-foreground">
                          {totalDuration < 60 ? `${totalDuration} min` : 
                           `${Math.floor(totalDuration / 60)}h ${totalDuration % 60 > 0 ? `${totalDuration % 60}min` : ''}`}
                        </span>
                      </div>
                      <div className="flex justify-between text-lg font-semibold pt-2 border-t border-border">
                        <span className="text-foreground">Total:</span>
                        <span className="text-primary">
                          {new Intl.NumberFormat('es-ES', {
                            style: 'currency',
                            currency: 'EUR'
                          })?.format(totalPrice)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <NavigationControls 
        onNext={handleNext}
        onBack={handleBack}
        nextLabel="Continuar con información"
        backLabel="Volver a servicios"
        canProceed={canProceed}
        isLoading={false}
      />
    </div>
  );
};

export default TimeSlotSelection;