import React from 'react';
import Icon from '../../../components/AppIcon';

const ServiceSummaryCard = ({ selectedServices = [], totalDuration = 0, totalPrice = 0 }) => {
  const formatDuration = (minutes) => {
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}min` : `${hours}h`;
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'CLP'
    })?.format(price);
  };

  if (selectedServices?.length === 0) {
    return (
      <div className="bg-card border border-border rounded-lg p-4 shadow-warm mb-6">
        <div className="flex items-center justify-center py-8">
          <div className="text-center">
            <Icon name="AlertCircle" size={48} className="text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">No hay servicios seleccionados</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg p-4 shadow-warm mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground flex items-center">
          <Icon name="Sparkles" size={20} className="mr-2 text-primary" />
          Servicios seleccionados
        </h3>
        <div className="text-right">
          <p className="text-sm text-muted-foreground">Duración total</p>
          <p className="text-lg font-bold text-primary">{formatDuration(totalDuration)}</p>
        </div>
      </div>
      <div className="space-y-3">
        {selectedServices?.map((service, index) => (
          <div key={index} className="flex justify-between items-center py-2 border-b border-border last:border-b-0">
            <div className="flex-1">
              <h4 className="font-medium text-foreground">{service?.name}</h4>
              <p className="text-sm text-muted-foreground">
                {formatDuration(service?.duration)}
              </p>
            </div>
            <div className="text-right">
              <p className="font-semibold text-foreground">{formatPrice(service?.price)}</p>
            </div>
          </div>
        ))}
      </div>
      {totalPrice > 0 && (
        <div className="mt-4 pt-4 border-t border-border">
          <div className="flex justify-between items-center">
            <span className="text-lg font-semibold text-foreground">Total:</span>
            <span className="text-xl font-bold text-primary">{formatPrice(totalPrice)}</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default ServiceSummaryCard;