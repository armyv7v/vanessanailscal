import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const TimeSlotGrid = ({ 
  selectedDate, 
  selectedTime, 
  onTimeSelect, 
  serviceDuration = 60,
  unavailableSlots = [],
  isLoading = false 
}) => {
  const [timeSlots, setTimeSlots] = useState([]);

  // Salon operating hours
  const SALON_HOURS = {
    start: 9, // 9:00 AM
    end: 19,  // 7:00 PM (changed from 20 to 19)
    interval: 30 // 30 minutes
  };

  useEffect(() => {
    if (selectedDate) {
      generateTimeSlots();
    }
  }, [selectedDate, unavailableSlots, serviceDuration]);

  const generateTimeSlots = () => {
    const slots = [];
    const today = new Date();
    const isToday = selectedDate && selectedDate?.toDateString() === today?.toDateString();
    const currentHour = today?.getHours();
    const currentMinute = today?.getMinutes();

    for (let hour = SALON_HOURS?.start; hour < SALON_HOURS?.end; hour++) {
      for (let minute = 0; minute < 60; minute += SALON_HOURS?.interval) {
        const slotTime = new Date(selectedDate);
        slotTime?.setHours(hour, minute, 0, 0);
        
        // Check if slot is in the past (for today only)
        const isPast = isToday && (hour < currentHour || (hour === currentHour && minute <= currentMinute));
        
        // Check if slot conflicts with unavailable times
        const slotTimeString = `${hour?.toString()?.padStart(2, '0')}:${minute?.toString()?.padStart(2, '0')}`;
        const isUnavailable = unavailableSlots?.includes(slotTimeString);
        
        // Check if there's enough time before salon closes
        const endTime = new Date(slotTime);
        endTime?.setMinutes(endTime?.getMinutes() + serviceDuration);
        const hasEnoughTime = endTime?.getHours() < SALON_HOURS?.end; // Changed <= to < for exact 19:00 cutoff
        
        // Check if slot overlaps with existing appointments
        const hasConflict = checkTimeConflict(slotTime, serviceDuration);

        slots?.push({
          time: slotTime,
          timeString: slotTimeString,
          displayTime: formatTime(slotTime),
          endTime: endTime,
          endTimeString: formatTime(endTime),
          isPast,
          isUnavailable,
          hasEnoughTime,
          hasConflict,
          isSelectable: !isPast && !isUnavailable && hasEnoughTime && !hasConflict
        });
      }
    }

    setTimeSlots(slots);
  };

  const checkTimeConflict = (startTime, duration) => {
    // Mock conflict checking - in real app, this would check against existing appointments
    const conflictTimes = [
      '10:00', '10:30', '14:00', '14:30', '15:00', '16:30', '17:00'
    ];
    
    const timeString = formatTime(startTime);
    return conflictTimes?.includes(timeString);
  };

  const formatTime = (date) => {
    return date?.toLocaleTimeString('es-ES', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });
  };

  const handleTimeClick = (slot) => {
    if (slot?.isSelectable) {
      onTimeSelect(slot?.time);
    }
  };

  const getSlotClassName = (slot) => {
    const baseClasses = "p-3 rounded-lg border transition-warm text-center min-h-[60px] flex flex-col justify-center";
    
    if (selectedTime && slot?.time?.getTime() === selectedTime?.getTime()) {
      return `${baseClasses} bg-primary text-primary-foreground border-primary shadow-warm-md font-semibold`;
    }
    
    if (!slot?.isSelectable) {
      if (slot?.isPast) {
        return `${baseClasses} bg-muted/30 text-muted-foreground border-muted cursor-not-allowed opacity-50`;
      }
      if (slot?.isUnavailable || slot?.hasConflict) {
        return `${baseClasses} bg-error/10 text-error border-error/30 cursor-not-allowed`;
      }
      if (!slot?.hasEnoughTime) {
        return `${baseClasses} bg-warning/10 text-warning border-warning/30 cursor-not-allowed`;
      }
    }
    
    return `${baseClasses} bg-card text-foreground border-border hover:bg-muted hover:border-primary/50 cursor-pointer`;
  };

  const getSlotIcon = (slot) => {
    if (selectedTime && slot?.time?.getTime() === selectedTime?.getTime()) {
      return <Icon name="Check" size={16} className="mx-auto mb-1" />;
    }
    if (slot?.hasConflict || slot?.isUnavailable) {
      return <Icon name="X" size={16} className="mx-auto mb-1" />;
    }
    if (!slot?.hasEnoughTime) {
      return <Icon name="Clock" size={16} className="mx-auto mb-1" />;
    }
    return <Icon name="Clock" size={16} className="mx-auto mb-1 opacity-60" />;
  };

  if (!selectedDate) {
    return (
      <div className="bg-card border border-border rounded-lg p-8 shadow-warm">
        <div className="text-center">
          <Icon name="Calendar" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">Selecciona una fecha</h3>
          <p className="text-muted-foreground">
            Primero elige una fecha para ver los horarios disponibles
          </p>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="bg-card border border-border rounded-lg p-4 shadow-warm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground flex items-center">
            <Icon name="Clock" size={20} className="mr-2 text-primary" />
            Horarios disponibles
          </h3>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {Array.from({ length: 12 })?.map((_, index) => (
            <div key={index} className="h-[60px] bg-muted animate-pulse rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg p-4 shadow-warm">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground flex items-center">
          <Icon name="Clock" size={20} className="mr-2 text-primary" />
          Horarios disponibles
        </h3>
        {selectedTime && (
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Hora seleccionada</p>
            <p className="font-semibold text-primary">{formatTime(selectedTime)}</p>
          </div>
        )}
      </div>
      {selectedTime && (
        <div className="mb-4 p-3 bg-primary/10 border border-primary/20 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Cita programada:</p>
              <p className="font-semibold text-primary">
                {formatTime(selectedTime)} - {formatTime(new Date(selectedTime.getTime() + serviceDuration * 60000))}
              </p>
            </div>
            <Icon name="CheckCircle" size={24} className="text-success" />
          </div>
        </div>
      )}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {timeSlots?.map((slot, index) => (
          <button
            key={index}
            onClick={() => handleTimeClick(slot)}
            disabled={!slot?.isSelectable}
            className={getSlotClassName(slot)}
          >
            {getSlotIcon(slot)}
            <span className="text-sm font-medium">{slot?.displayTime}</span>
            {!slot?.isSelectable && (
              <span className="text-xs mt-1 opacity-75">
                {slot?.isPast ? 'Pasado' : 
                 slot?.hasConflict ? 'Ocupado': slot?.isUnavailable ?'No disponible': !slot?.hasEnoughTime ?'Tiempo insuficiente' : ''}
              </span>
            )}
          </button>
        ))}
      </div>
      {timeSlots?.filter(slot => slot?.isSelectable)?.length === 0 && (
        <div className="mt-6 text-center py-8">
          <Icon name="AlertCircle" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h4 className="text-lg font-semibold text-foreground mb-2">
            No hay horarios disponibles
          </h4>
          <p className="text-muted-foreground">
            Por favor, selecciona otra fecha para ver horarios disponibles
          </p>
        </div>
      )}
      {/* Legend */}
      <div className="mt-6 pt-4 border-t border-border">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-primary rounded"></div>
            <span className="text-muted-foreground">Seleccionado</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-card border border-border rounded"></div>
            <span className="text-muted-foreground">Disponible</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-error/10 border border-error/30 rounded"></div>
            <span className="text-muted-foreground">Ocupado</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-muted/30 rounded"></div>
            <span className="text-muted-foreground">No disponible</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TimeSlotGrid;