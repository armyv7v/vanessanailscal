import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const DatePicker = ({ selectedDate, onDateSelect, unavailableDates = [] }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [calendarDays, setCalendarDays] = useState([]);

  const monthNames = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ];

  const dayNames = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

  useEffect(() => {
    generateCalendarDays();
  }, [currentMonth]);

  const generateCalendarDays = () => {
    const year = currentMonth?.getFullYear();
    const month = currentMonth?.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startDate = new Date(firstDay);
    startDate?.setDate(startDate?.getDate() - firstDay?.getDay());

    const days = [];
    const today = new Date();
    today?.setHours(0, 0, 0, 0);

    for (let i = 0; i < 42; i++) {
      const date = new Date(startDate);
      date?.setDate(startDate?.getDate() + i);
      
      const isCurrentMonth = date?.getMonth() === month;
      const isPast = date < today;
      const isToday = date?.toDateString() === today?.toDateString();
      const isUnavailable = unavailableDates?.some(unavailableDate => 
        new Date(unavailableDate)?.toDateString() === date?.toDateString()
      );
      const isSelected = selectedDate && date?.toDateString() === selectedDate?.toDateString();

      days?.push({
        date: new Date(date),
        day: date?.getDate(),
        isCurrentMonth,
        isPast,
        isToday,
        isUnavailable,
        isSelected,
        isSelectable: isCurrentMonth && !isPast && !isUnavailable
      });
    }

    setCalendarDays(days);
  };

  const navigateMonth = (direction) => {
    const newMonth = new Date(currentMonth);
    newMonth?.setMonth(currentMonth?.getMonth() + direction);
    setCurrentMonth(newMonth);
  };

  const handleDateClick = (dayInfo) => {
    if (dayInfo?.isSelectable) {
      onDateSelect(dayInfo?.date);
    }
  };

  const formatSelectedDate = () => {
    if (!selectedDate) return '';
    return selectedDate?.toLocaleDateString('es-ES', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 shadow-warm mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground flex items-center">
          <Icon name="Calendar" size={20} className="mr-2 text-primary" />
          Seleccionar fecha
        </h3>
      </div>
      {selectedDate && (
        <div className="mb-4 p-3 bg-primary/10 border border-primary/20 rounded-lg">
          <p className="text-sm text-muted-foreground">Fecha seleccionada:</p>
          <p className="font-semibold text-primary capitalize">{formatSelectedDate()}</p>
        </div>
      )}
      {/* Calendar Header */}
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={() => navigateMonth(-1)}
          className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-warm"
        >
          <Icon name="ChevronLeft" size={20} />
        </button>
        
        <h4 className="text-lg font-semibold text-foreground">
          {monthNames?.[currentMonth?.getMonth()]} {currentMonth?.getFullYear()}
        </h4>
        
        <button
          onClick={() => navigateMonth(1)}
          className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-warm"
        >
          <Icon name="ChevronRight" size={20} />
        </button>
      </div>
      {/* Day Headers */}
      <div className="grid grid-cols-7 gap-1 mb-2">
        {dayNames?.map(day => (
          <div key={day} className="p-2 text-center text-sm font-medium text-muted-foreground">
            {day}
          </div>
        ))}
      </div>
      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-1">
        {calendarDays?.map((dayInfo, index) => (
          <button
            key={index}
            onClick={() => handleDateClick(dayInfo)}
            disabled={!dayInfo?.isSelectable}
            className={`
              p-2 text-sm rounded-lg transition-warm min-h-[40px] flex items-center justify-center
              ${dayInfo?.isSelected 
                ? 'bg-primary text-primary-foreground shadow-warm font-semibold' 
                : dayInfo?.isToday
                  ? 'bg-accent text-accent-foreground font-medium'
                  : dayInfo?.isSelectable
                    ? 'text-foreground hover:bg-muted hover:text-foreground'
                    : dayInfo?.isCurrentMonth
                      ? dayInfo?.isUnavailable
                        ? 'text-muted-foreground bg-muted/50 cursor-not-allowed'
                        : 'text-muted-foreground cursor-not-allowed' :'text-muted-foreground/50 cursor-not-allowed'
              }
            `}
          >
            <span className="relative">
              {dayInfo?.day}
              {dayInfo?.isUnavailable && dayInfo?.isCurrentMonth && (
                <div className="absolute -top-1 -right-1 w-2 h-2 bg-error rounded-full"></div>
              )}
            </span>
          </button>
        ))}
      </div>
      {/* Legend */}
      <div className="mt-4 pt-4 border-t border-border">
        <div className="flex flex-wrap gap-4 text-xs">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-primary rounded"></div>
            <span className="text-muted-foreground">Seleccionado</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-accent rounded"></div>
            <span className="text-muted-foreground">Hoy</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-muted/50 rounded relative">
              <div className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-error rounded-full"></div>
            </div>
            <span className="text-muted-foreground">No disponible</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DatePicker;