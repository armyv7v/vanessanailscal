import React from 'react';
import ServiceCard from './ServiceCard';

const ServiceGrid = ({ 
  services, 
  selectedServices, 
  onToggleService, 
  serviceDurations, 
  onDurationChange 
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {services?.map((service) => (
        <ServiceCard
          key={service?.id}
          service={service}
          isSelected={selectedServices?.includes(service?.id)}
          onToggleSelect={onToggleService}
          selectedDuration={serviceDurations?.[service?.id] || service?.baseDuration}
          onDurationChange={onDurationChange}
        />
      ))}
    </div>
  );
};

export default ServiceGrid;