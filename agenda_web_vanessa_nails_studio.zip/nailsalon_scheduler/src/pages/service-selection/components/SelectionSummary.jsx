import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SelectionSummary = ({ 
  selectedServices, 
  serviceDurations, 
  services, 
  onClearAll, 
  onProceed,
  className = '' 
}) => {
  const getSelectedServiceDetails = () => {
    return selectedServices?.map(serviceId => {
      const service = services?.find(s => s?.id === serviceId);
      const duration = serviceDurations?.[serviceId] || service?.baseDuration || 0;
      return { ...service, selectedDuration: duration };
    })?.filter(Boolean);
  };

  const selectedServiceDetails = getSelectedServiceDetails();
  const totalDuration = selectedServiceDetails?.reduce((sum, service) => sum + service?.selectedDuration, 0);
  const totalPrice = selectedServiceDetails?.reduce((sum, service) => sum + service?.basePrice, 0);

  const formatDuration = (minutes) => {
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}min` : `${hours}h`;
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'CLP'
    })?.format(price / 1); // Converting from Chilean pesos to approximate USD
  };

  if (selectedServices?.length === 0) {
    return null;
  }

  return (
    <div className={`bg-card border border-border rounded-lg p-4 shadow-warm ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground flex items-center">
          <Icon name="ShoppingBag" size={20} className="mr-2 text-primary" />
          Servicios seleccionados ({selectedServices?.length})
        </h3>
        <Button
          variant="ghost"
          size="sm"
          onClick={onClearAll}
          iconName="X"
          iconPosition="left"
          className="text-muted-foreground hover:text-error"
        >
          Limpiar todo
        </Button>
      </div>
      <div className="space-y-3 mb-4">
        {selectedServiceDetails?.map((service) => (
          <div key={service?.id} className="flex items-center justify-between py-2 border-b border-border last:border-b-0">
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-medium text-foreground truncate">
                {service?.name}
              </h4>
              <p className="text-xs text-muted-foreground">
                {formatDuration(service?.selectedDuration)}
              </p>
            </div>
            <div className="text-sm font-medium text-foreground ml-3">
              {formatPrice(service?.basePrice)}
            </div>
          </div>
        ))}
      </div>
      <div className="border-t border-border pt-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-muted-foreground">Duración total:</span>
          <span className="text-sm font-medium text-foreground">
            {formatDuration(totalDuration)}
          </span>
        </div>
        <div className="flex items-center justify-between mb-4">
          <span className="text-base font-semibold text-foreground">Total estimado:</span>
          <span className="text-lg font-bold text-primary">
            {formatPrice(totalPrice)}
          </span>
        </div>
        
        <Button
          variant="default"
          fullWidth
          onClick={onProceed}
          iconName="ArrowRight"
          iconPosition="right"
          className="bg-primary hover:bg-primary/90"
        >
          Continuar a Horarios
        </Button>
      </div>
    </div>
  );
};

export default SelectionSummary;