import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import { Checkbox } from '../../../components/ui/Checkbox';

const ServiceCard = ({ 
  service, 
  isSelected, 
  onToggleSelect, 
  selectedDuration, 
  onDurationChange,
  className = '' 
}) => {
  const formatPrice = (price) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(price);
  };

  const formatDuration = (minutes) => {
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}min` : `${hours}h`;
  };

  const handleDurationChange = (change) => {
    const newDuration = Math.max(service?.minDuration, Math.min(service?.maxDuration, selectedDuration + change));
    onDurationChange(service?.id, newDuration);
  };

  return (
    <div className={`
      bg-card border border-border rounded-lg overflow-hidden shadow-warm transition-warm hover:shadow-warm-md
      ${isSelected ? 'ring-2 ring-primary ring-opacity-50 bg-primary/5' : ''}
      ${!service?.available ? 'opacity-60' : ''}
      ${className}
    `}>
      {/* Service Image */}
      <div className="relative h-48 overflow-hidden">
        <Image
          src={service?.image}
          alt={service?.name}
          className="w-full h-full object-cover"
        />
        {!service?.available && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <div className="bg-white rounded-lg px-3 py-1">
              <span className="text-sm font-medium text-foreground">No disponible</span>
            </div>
          </div>
        )}
        {service?.popular && (
          <div className="absolute top-3 right-3 bg-primary text-primary-foreground px-2 py-1 rounded-full text-xs font-medium">
            Popular
          </div>
        )}
      </div>
      {/* Service Content */}
      <div className="p-4">
        {/* Header with Checkbox */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-semibold text-foreground mb-1 line-clamp-2">
              {service?.name}
            </h3>
            <div className="flex items-center space-x-4 text-sm text-muted-foreground">
              <span className="flex items-center">
                <Icon name="Clock" size={14} className="mr-1" />
                {formatDuration(service?.baseDuration)}
              </span>
              <span className="font-semibold text-primary">
                {formatPrice(service?.basePrice)}
              </span>
            </div>
          </div>
          <Checkbox
            checked={isSelected}
            onChange={(e) => onToggleSelect(service?.id, e?.target?.checked)}
            disabled={!service?.available}
            className="ml-3 flex-shrink-0"
          />
        </div>

        {/* Description */}
        <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
          {service?.description}
        </p>

        {/* Duration Selector - Only show when selected */}
        {isSelected && (
          <div className="border-t border-border pt-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-foreground">
                Duración personalizada:
              </span>
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => handleDurationChange(-15)}
                  disabled={selectedDuration <= service?.minDuration}
                  className="w-8 h-8 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted transition-warm disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Icon name="Minus" size={14} />
                </button>
                <span className="text-sm font-medium text-foreground min-w-[60px] text-center">
                  {formatDuration(selectedDuration)}
                </span>
                <button
                  onClick={() => handleDurationChange(15)}
                  disabled={selectedDuration >= service?.maxDuration}
                  className="w-8 h-8 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted transition-warm disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Icon name="Plus" size={14} />
                </button>
              </div>
            </div>
            <div className="mt-2 text-xs text-muted-foreground">
              Rango: {formatDuration(service?.minDuration)} - {formatDuration(service?.maxDuration)}
            </div>
          </div>
        )}

        {/* Service Features */}
        {service?.features && service?.features?.length > 0 && (
          <div className="mt-3 pt-3 border-t border-border">
            <div className="flex flex-wrap gap-1">
              {service?.features?.slice(0, 3)?.map((feature, index) => (
                <span
                  key={index}
                  className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-muted text-muted-foreground"
                >
                  {feature}
                </span>
              ))}
              {service?.features?.length > 3 && (
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-muted text-muted-foreground">
                  +{service?.features?.length - 3} más
                </span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ServiceCard;