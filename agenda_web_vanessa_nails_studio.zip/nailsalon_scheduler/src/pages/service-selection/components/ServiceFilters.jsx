import React from 'react';
import Icon from '../../../components/AppIcon';
import Select from '../../../components/ui/Select';

const ServiceFilters = ({ 
  selectedCategory, 
  onCategoryChange, 
  priceRange, 
  onPriceRangeChange, 
  sortBy, 
  onSortChange,
  searchQuery,
  onSearchChange 
}) => {
  const categoryOptions = [
    { value: 'all', label: 'Todos los servicios' },
    { value: 'manicure', label: 'Manicura' },
    { value: 'pedicure', label: 'Pedicura' },
    { value: 'nail-art', label: 'Nail Art' },
    { value: 'treatments', label: 'Tratamientos' }
  ];

  const priceRangeOptions = [
    { value: 'all', label: 'Todos los precios' },
    { value: '0-18000', label: 'Hasta $18.000' },
    { value: '18000-28000', label: '$18.000 - $28.000' },
    { value: '28000-35000', label: '$28.000 - $35.000' },
    { value: '35000+', label: 'Más de $35.000' }
  ];

  const sortOptions = [
    { value: 'popular', label: 'Más populares' },
    { value: 'price-low', label: 'Precio: menor a mayor' },
    { value: 'price-high', label: 'Precio: mayor a menor' },
    { value: 'duration-short', label: 'Duración: más corta' },
    { value: 'duration-long', label: 'Duración: más larga' },
    { value: 'name', label: 'Nombre A-Z' }
  ];

  return (
    <div className="bg-card border border-border rounded-lg p-4 mb-6 shadow-warm">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground flex items-center">
          <Icon name="Filter" size={20} className="mr-2 text-primary" />
          Filtros y búsqueda
        </h3>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Search */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Icon name="Search" size={16} className="text-muted-foreground" />
          </div>
          <input
            type="text"
            placeholder="Buscar servicios..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e?.target?.value)}
            className="w-full pl-10 pr-4 py-2 border border-border rounded-lg bg-input text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-warm"
          />
        </div>

        {/* Category Filter */}
        <Select
          placeholder="Categoría"
          options={categoryOptions}
          value={selectedCategory}
          onChange={onCategoryChange}
        />

        {/* Price Range Filter */}
        <Select
          placeholder="Rango de precio"
          options={priceRangeOptions}
          value={priceRange}
          onChange={onPriceRangeChange}
        />

        {/* Sort Options */}
        <Select
          placeholder="Ordenar por"
          options={sortOptions}
          value={sortBy}
          onChange={onSortChange}
        />
      </div>
    </div>
  );
};

export default ServiceFilters;