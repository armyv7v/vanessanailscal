import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const WelcomeSection = ({ className = '' }) => {
  return (
    <div className={`bg-gradient-to-r from-primary/10 to-accent/10 rounded-lg p-6 mb-8 ${className}`}>
      <div className="flex flex-col lg:flex-row items-center gap-6">
        <div className="flex-1">
          <div className="flex items-center mb-3">
            <Icon name="Sparkles" size={24} className="text-primary mr-2" />
            <h1 className="text-2xl lg:text-3xl font-bold text-foreground">
              Bienvenida a Vanessa Nails
            </h1>
          </div>
          <p className="text-lg text-muted-foreground mb-4">
            Selecciona los servicios que deseas reservar. Puedes personalizar la duración de cada tratamiento según tus necesidades.
          </p>
          <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
            <div className="flex items-center">
              <Icon name="Clock" size={16} className="mr-2 text-primary" />
              <span>Reserva flexible</span>
            </div>
            <div className="flex items-center">
              <Icon name="Star" size={16} className="mr-2 text-primary" />
              <span>Profesionales certificadas</span>
            </div>
            <div className="flex items-center">
              <Icon name="Shield" size={16} className="mr-2 text-primary" />
              <span>Productos de calidad</span>
            </div>
          </div>
        </div>
        <div className="flex-shrink-0">
          <div className="w-32 h-32 lg:w-40 lg:h-40 rounded-full overflow-hidden shadow-warm-lg">
            <Image
              src="https://images.unsplash.com/photo-1604654894610-df63bc536371?w=400&h=400&fit=crop&crop=center"
              alt="Salon de uñas profesional"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default WelcomeSection;