import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import ProgressIndicator from '../../components/ui/ProgressIndicator';
import NavigationControls from '../../components/ui/NavigationControls';
import WelcomeSection from './components/WelcomeSection';
import ServiceFilters from './components/ServiceFilters';
import ServiceGrid from './components/ServiceGrid';
import SelectionSummary from './components/SelectionSummary';
import Icon from '../../components/AppIcon';

const ServiceSelection = () => {
  const navigate = useNavigate();
  
  // Mock services data
  const mockServices = [
    {
      id: 'retoque-mantenimiento',
      name: 'Retoque (Mantenimiento)',
      description: 'Servicio de mantenimiento y retoque para mantener tus uñas en perfecto estado. Incluye limado, pulido y corrección de detalles.',
      category: 'treatments',
      basePrice: 25000,
      baseDuration: 120,
      minDuration: 120,
      maxDuration: 150,
      image: 'https://images.unsplash.com/photo-1604654894610-df63bc536371?w=500&h=300&fit=crop',
      available: true,
      popular: true,
      features: ['Mantenimiento profesional', 'Limado y pulido', 'Corrección de detalles', 'Duración extendida']
    },
    {
      id: 'reconstruccion-onicofagia',
      name: 'Reconstrucción Uñas Mordidas (Onicofagía)',
      description: 'Reconstrucción especializada para uñas mordidas con técnicas avanzadas de recuperación y fortalecimiento.',
      category: 'treatments',
      basePrice: 45000,
      baseDuration: 180,
      minDuration: 180,
      maxDuration: 210,
      image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=500&h=300&fit=crop',
      available: true,
      popular: false,
      features: ['Reconstrucción especializada', 'Técnicas avanzadas', 'Fortalecimiento', 'Recuperación de uñas']
    },
    {
      id: 'unas-acrilicas',
      name: 'Uñas Acrílicas',
      description: 'Extensión de uñas con acrílico de alta calidad. Duraderas y personalizables con diseños únicos.',
      category: 'extensions',
      basePrice: 35000,
      baseDuration: 180,
      minDuration: 180,
      maxDuration: 210,
      image: 'https://images.unsplash.com/photo-1560750588-73207b1ef5b8?w=500&h=300&fit=crop',
      available: true,
      popular: true,
      features: ['Extensión acrílica', 'Alta durabilidad', 'Personalizable', 'Diseños únicos']
    },
    {
      id: 'unas-polygel',
      name: 'Uñas Polygel',
      description: 'Técnica moderna de extensión con polygel. Más ligero que el acrílico y con acabado natural.',
      category: 'extensions',
      basePrice: 40000,
      baseDuration: 180,
      minDuration: 180,
      maxDuration: 210,
      image: 'https://images.unsplash.com/photo-1515688594390-b649af70d282?w=500&h=300&fit=crop',
      available: true,
      popular: true,
      features: ['Técnica moderna', 'Más ligero', 'Acabado natural', 'Larga duración']
    },
    {
      id: 'unas-sofgel',
      name: 'Uñas Sofgel',
      description: 'Sistema de extensión con sofgel, flexible y resistente. Ideal para un look natural y duradero.',
      category: 'extensions',
      basePrice: 38000,
      baseDuration: 180,
      minDuration: 180,
      maxDuration: 210,
      image: 'https://images.unsplash.com/photo-1604654894610-df63bc536371?w=500&h=300&fit=crop',
      available: true,
      popular: false,
      features: ['Sistema sofgel', 'Flexible y resistente', 'Look natural', 'Duradero']
    },
    {
      id: 'kapping-bano-polygel-acrilico',
      name: 'Kapping o Baño Polygel o Acrílico sobre uña natural',
      description: 'Fortalecimiento de la uña natural con una capa protectora de polygel o acrílico. Refuerza sin alargar.',
      category: 'treatments',
      basePrice: 30000,
      baseDuration: 150,
      minDuration: 150,
      maxDuration: 180,
      image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=500&h=300&fit=crop',
      available: true,
      popular: false,
      features: ['Fortalecimiento natural', 'Capa protectora', 'Sin alargado', 'Refuerza la uña']
    },
    {
      id: 'reforzamiento-nivelacion-rubber',
      name: 'Reforzamiento Nivelación Rubber',
      description: 'Técnica de reforzamiento y nivelación con rubber base. Perfecto para uñas irregulares o débiles.',
      category: 'treatments',
      basePrice: 28000,
      baseDuration: 150,
      minDuration: 150,
      maxDuration: 180,
      image: 'https://images.unsplash.com/photo-1560750588-73207b1ef5b8?w=500&h=300&fit=crop',
      available: true,
      popular: false,
      features: ['Reforzamiento rubber', 'Nivelación perfecta', 'Para uñas irregulares', 'Fortalecimiento']
    },
    {
      id: 'esmaltado-permanente',
      name: 'Esmaltado Permanente',
      description: 'Esmaltado con gel de larga duración. Brillo intenso y resistente por semanas.',
      category: 'manicure',
      basePrice: 18000,
      baseDuration: 90,
      minDuration: 90,
      maxDuration: 120,
      image: 'https://images.unsplash.com/photo-1515688594390-b649af70d282?w=500&h=300&fit=crop',
      available: true,
      popular: true,
      features: ['Gel permanente', 'Larga duración', 'Brillo intenso', 'Resistente']
    }
  ];

  // State management
  const [selectedServices, setSelectedServices] = useState([]);
  const [serviceDurations, setServiceDurations] = useState({});
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [priceRange, setPriceRange] = useState('all');
  const [sortBy, setSortBy] = useState('popular');

  // Load saved data from localStorage on component mount
  useEffect(() => {
    const savedBookingData = localStorage.getItem('nailsalon_booking');
    if (savedBookingData) {
      try {
        const bookingData = JSON.parse(savedBookingData);
        if (bookingData?.selectedServices) {
          setSelectedServices(bookingData?.selectedServices?.map(s => s?.id));
          const durations = {};
          bookingData?.selectedServices?.forEach(service => {
            durations[service.id] = service?.selectedDuration;
          });
          setServiceDurations(durations);
        }
      } catch (error) {
        console.error('Error loading saved booking data:', error);
      }
    }
  }, []);

  // Filter and sort services
  const filteredAndSortedServices = useMemo(() => {
    let filtered = mockServices?.filter(service => {
      // Search filter
      if (searchQuery && !service?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase()) && 
          !service?.description?.toLowerCase()?.includes(searchQuery?.toLowerCase())) {
        return false;
      }

      // Category filter
      if (selectedCategory !== 'all' && service?.category !== selectedCategory) {
        return false;
      }

      // Price range filter
      if (priceRange !== 'all') {
        const [min, max] = priceRange?.split('-')?.map(p => p?.replace('+', ''));
        const minPrice = parseInt(min);
        const maxPrice = max ? parseInt(max) : Infinity;
        
        if (service?.basePrice < minPrice || service?.basePrice > maxPrice) {
          return false;
        }
      }

      return true;
    });

    // Sort services
    filtered?.sort((a, b) => {
      switch (sortBy) {
        case 'price-low':
          return a?.basePrice - b?.basePrice;
        case 'price-high':
          return b?.basePrice - a?.basePrice;
        case 'duration-short':
          return a?.baseDuration - b?.baseDuration;
        case 'duration-long':
          return b?.baseDuration - a?.baseDuration;
        case 'name':
          return a?.name?.localeCompare(b?.name);
        case 'popular':
        default:
          return (b?.popular ? 1 : 0) - (a?.popular ? 1 : 0);
      }
    });

    return filtered;
  }, [mockServices, searchQuery, selectedCategory, priceRange, sortBy]);

  // Handle service selection
  const handleToggleService = (serviceId, isSelected) => {
    if (isSelected) {
      setSelectedServices(prev => [...prev, serviceId]);
      const service = mockServices?.find(s => s?.id === serviceId);
      if (service) {
        setServiceDurations(prev => ({
          ...prev,
          [serviceId]: service?.baseDuration
        }));
      }
    } else {
      setSelectedServices(prev => prev?.filter(id => id !== serviceId));
      setServiceDurations(prev => {
        const newDurations = { ...prev };
        delete newDurations?.[serviceId];
        return newDurations;
      });
    }
  };

  // Handle duration change
  const handleDurationChange = (serviceId, newDuration) => {
    setServiceDurations(prev => ({
      ...prev,
      [serviceId]: newDuration
    }));
  };

  // Clear all selections
  const handleClearAll = () => {
    setSelectedServices([]);
    setServiceDurations({});
  };

  // Save booking data and proceed to next step
  const handleProceed = () => {
    const selectedServiceDetails = selectedServices?.map(serviceId => {
      const service = mockServices?.find(s => s?.id === serviceId);
      return {
        ...service,
        selectedDuration: serviceDurations?.[serviceId] || service?.baseDuration
      };
    });

    const totalDuration = selectedServiceDetails?.reduce((sum, service) => sum + service?.selectedDuration, 0);
    const totalPrice = selectedServiceDetails?.reduce((sum, service) => sum + service?.basePrice, 0);

    const bookingData = {
      selectedServices: selectedServiceDetails,
      totalDuration,
      totalPrice,
      timestamp: new Date()?.toISOString()
    };

    localStorage.setItem('nailsalon_booking', JSON.stringify(bookingData));
    navigate('/time-slot-selection');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-32 pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Progress Indicator */}
          <ProgressIndicator className="mb-8" />

          {/* Welcome Section */}
          <WelcomeSection />

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-3">
              {/* Service Filters */}
              <ServiceFilters
                selectedCategory={selectedCategory}
                onCategoryChange={setSelectedCategory}
                priceRange={priceRange}
                onPriceRangeChange={setPriceRange}
                sortBy={sortBy}
                onSortChange={setSortBy}
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
              />

              {/* Results Info */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-4">
                  <h2 className="text-xl font-semibold text-foreground">
                    Servicios disponibles
                  </h2>
                  <span className="text-sm text-muted-foreground bg-muted px-2 py-1 rounded-full">
                    {filteredAndSortedServices?.length} servicios
                  </span>
                </div>
                {selectedServices?.length > 0 && (
                  <div className="flex items-center text-sm text-primary">
                    <Icon name="Check" size={16} className="mr-1" />
                    {selectedServices?.length} seleccionado{selectedServices?.length !== 1 ? 's' : ''}
                  </div>
                )}
              </div>

              {/* Service Grid */}
              {filteredAndSortedServices?.length > 0 ? (
                <ServiceGrid
                  services={filteredAndSortedServices}
                  selectedServices={selectedServices}
                  onToggleService={handleToggleService}
                  serviceDurations={serviceDurations}
                  onDurationChange={handleDurationChange}
                />
              ) : (
                <div className="text-center py-12">
                  <Icon name="Search" size={48} className="mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium text-foreground mb-2">
                    No se encontraron servicios
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    Intenta ajustar los filtros o términos de búsqueda
                  </p>
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedCategory('all');
                      setPriceRange('all');
                    }}
                    className="text-primary hover:text-primary/80 font-medium"
                  >
                    Limpiar filtros
                  </button>
                </div>
              )}
            </div>

            {/* Sidebar - Selection Summary */}
            <div className="lg:col-span-1">
              <SelectionSummary
                selectedServices={selectedServices}
                serviceDurations={serviceDurations}
                services={mockServices}
                onClearAll={handleClearAll}
                onProceed={handleProceed}
                className="sticky top-32"
              />
            </div>
          </div>
        </div>
      </main>
      {/* Navigation Controls */}
      <NavigationControls
        canProceed={selectedServices?.length > 0}
        nextLabel="Continuar a Horarios"
        onNext={handleProceed}
        showBack={false}
      />
    </div>
  );
};

export default ServiceSelection;