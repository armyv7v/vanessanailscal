import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import AppointmentConfirmation from './pages/appointment-confirmation';
import CustomerInformation from './pages/customer-information';
import TimeSlotSelection from './pages/time-slot-selection';
import ServiceSelection from './pages/service-selection';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<AppointmentConfirmation />} />
        <Route path="/appointment-confirmation" element={<AppointmentConfirmation />} />
        <Route path="/customer-information" element={<CustomerInformation />} />
        <Route path="/time-slot-selection" element={<TimeSlotSelection />} />
        <Route path="/service-selection" element={<ServiceSelection />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
