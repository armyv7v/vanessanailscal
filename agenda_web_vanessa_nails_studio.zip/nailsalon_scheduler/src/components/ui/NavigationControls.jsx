import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Button from './Button';


const NavigationControls = ({ 
  onNext,
  onBack,
  nextLabel = 'Continuar',
  backLabel = 'Volver',
  canProceed = true,
  isLoading = false,
  showBack = true,
  className = ''
}) => {
  const navigate = useNavigate();
  const location = useLocation();

  const steps = [
    { path: '/service-selection', order: 1 },
    { path: '/time-slot-selection', order: 2 },
    { path: '/customer-information', order: 3 },
    { path: '/appointment-confirmation', order: 4 }
  ];

  const getCurrentStep = () => {
    return steps?.find(step => step?.path === location.pathname);
  };

  const getNextStep = () => {
    const current = getCurrentStep();
    if (!current) return null;
    return steps?.find(step => step?.order === current?.order + 1);
  };

  const getPreviousStep = () => {
    const current = getCurrentStep();
    if (!current) return null;
    return steps?.find(step => step?.order === current?.order - 1);
  };

  const handleNext = () => {
    if (onNext) {
      onNext();
    } else {
      const nextStep = getNextStep();
      if (nextStep) {
        navigate(nextStep?.path);
      }
    }
  };

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      const previousStep = getPreviousStep();
      if (previousStep) {
        navigate(previousStep?.path);
      }
    }
  };

  const currentStep = getCurrentStep();
  const isFirstStep = currentStep?.order === 1;
  const isLastStep = currentStep?.order === 4;

  return (
    <div className={`sticky bottom-0 bg-background border-t border-border shadow-warm-lg ${className}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between">
          {/* Back Button */}
          <div className="flex-1">
            {showBack && !isFirstStep && (
              <Button
                variant="ghost"
                onClick={handleBack}
                iconName="ArrowLeft"
                iconPosition="left"
                className="text-muted-foreground hover:text-foreground"
              >
                {backLabel}
              </Button>
            )}
          </div>

          {/* Step Indicator (Mobile) */}
          <div className="flex-1 flex justify-center md:hidden">
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <span>{currentStep?.order || 1}</span>
              <span>/</span>
              <span>{steps?.length}</span>
            </div>
          </div>

          {/* Next Button */}
          <div className="flex-1 flex justify-end">
            {!isLastStep ? (
              <Button
                variant="default"
                onClick={handleNext}
                disabled={!canProceed}
                loading={isLoading}
                iconName="ArrowRight"
                iconPosition="right"
                className="min-w-[120px]"
              >
                {nextLabel}
              </Button>
            ) : (
              <Button
                variant="default"
                onClick={handleNext}
                disabled={!canProceed}
                loading={isLoading}
                iconName="Check"
                iconPosition="right"
                className="min-w-[140px] bg-success hover:bg-success/90"
              >
                Confirmar reserva
              </Button>
            )}
          </div>
        </div>

        {/* Progress Bar (Mobile) */}
        <div className="mt-3 md:hidden">
          <div className="w-full bg-muted rounded-full h-1">
            <div 
              className="bg-primary h-1 rounded-full transition-warm"
              style={{ 
                width: `${((currentStep?.order || 1) / steps?.length) * 100}%` 
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default NavigationControls;