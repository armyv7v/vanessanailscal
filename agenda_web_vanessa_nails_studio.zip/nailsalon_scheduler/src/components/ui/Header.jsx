import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import Icon from '../AppIcon';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const navigationItems = [
    { label: 'Servicios', path: '/service-selection', step: 1 },
    { label: 'Horario', path: '/time-slot-selection', step: 2 },
    { label: 'Información', path: '/customer-information', step: 3 },
    { label: 'Confirmación', path: '/appointment-confirmation', step: 4 }
  ];

  const getCurrentStep = () => {
    const currentItem = navigationItems?.find(item => item?.path === location.pathname);
    return currentItem ? currentItem?.step : 1;
  };

  const isStepCompleted = (step) => {
    return step < getCurrentStep();
  };

  const isStepActive = (step) => {
    return step === getCurrentStep();
  };

  const Logo = () => (
    <div className="flex items-center space-x-3">
      <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center shadow-warm">
        <Icon name="Sparkles" size={24} color="white" strokeWidth={2} />
      </div>
      <div className="flex flex-col">
        <span className="text-xl font-semibold text-foreground">Vanessa Nails</span>
        <span className="text-sm text-muted-foreground font-medium">Scheduler</span>
      </div>
    </div>
  );

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background border-b border-border shadow-warm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          <Logo />
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a 
              href="tel:+56991744464" 
              className="flex items-center space-x-2 text-muted-foreground hover:text-primary transition-warm"
            >
              <Icon name="Phone" size={18} />
              <span className="text-sm font-medium">+56991744464</span>
            </a>
            <button className="flex items-center space-x-2 text-muted-foreground hover:text-primary transition-warm">
              <Icon name="Globe" size={18} />
              <span className="text-sm font-medium">ES</span>
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg text-muted-foreground hover:text-primary hover:bg-muted transition-warm"
          >
            <Icon name={isMenuOpen ? "X" : "Menu"} size={24} />
          </button>
        </div>

        {/* Progress Indicator */}
        <div className="pb-4">
          <div className="flex items-center justify-between max-w-2xl mx-auto">
            {navigationItems?.map((item, index) => (
              <div key={item?.step} className="flex items-center">
                <div className="flex flex-col items-center">
                  <div className={`
                    w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-warm
                    ${isStepActive(item?.step) 
                      ? 'bg-primary text-primary-foreground shadow-warm-md' 
                      : isStepCompleted(item?.step)
                        ? 'bg-success text-success-foreground'
                        : 'bg-muted text-muted-foreground'
                    }
                  `}>
                    {isStepCompleted(item?.step) ? (
                      <Icon name="Check" size={16} />
                    ) : (
                      item?.step
                    )}
                  </div>
                  <span className={`
                    mt-2 text-xs font-medium hidden sm:block
                    ${isStepActive(item?.step) 
                      ? 'text-primary' 
                      : isStepCompleted(item?.step)
                        ? 'text-success' :'text-muted-foreground'
                    }
                  `}>
                    {item?.label}
                  </span>
                </div>
                {index < navigationItems?.length - 1 && (
                  <div className={`
                    w-12 sm:w-16 h-0.5 mx-2 transition-warm
                    ${isStepCompleted(item?.step + 1) 
                      ? 'bg-success' :'bg-border'
                    }
                  `} />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-card border-t border-border shadow-warm-lg">
          <div className="px-4 py-4 space-y-4">
            <a 
              href="tel:+56930072631" 
              className="flex items-center space-x-3 p-3 rounded-lg text-muted-foreground hover:text-primary hover:bg-muted transition-warm"
              onClick={() => setIsMenuOpen(false)}
            >
              <Icon name="Phone" size={20} />
              <span className="font-medium">+56930072631</span>
            </a>
            <button 
              className="flex items-center space-x-3 p-3 rounded-lg text-muted-foreground hover:text-primary hover:bg-muted transition-warm w-full text-left"
              onClick={() => setIsMenuOpen(false)}
            >
              <Icon name="Globe" size={20} />
              <span className="font-medium">Cambiar idioma</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;