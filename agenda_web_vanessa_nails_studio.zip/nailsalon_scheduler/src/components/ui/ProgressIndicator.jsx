import React from 'react';
import { useLocation } from 'react-router-dom';
import Icon from '../AppIcon';

const ProgressIndicator = ({ className = '' }) => {
  const location = useLocation();

  const steps = [
    { id: 1, label: 'Servicios', path: '/service-selection' },
    { id: 2, label: 'Horario', path: '/time-slot-selection' },
    { id: 3, label: 'Información', path: '/customer-information' },
    { id: 4, label: 'Confirmación', path: '/appointment-confirmation' }
  ];

  const getCurrentStep = () => {
    const currentStep = steps?.find(step => step?.path === location.pathname);
    return currentStep ? currentStep?.id : 1;
  };

  const currentStepId = getCurrentStep();

  const isStepCompleted = (stepId) => stepId < currentStepId;
  const isStepActive = (stepId) => stepId === currentStepId;

  return (
    <div className={`w-full ${className}`}>
      {/* Mobile Progress Bar */}
      <div className="block sm:hidden">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-muted-foreground">
            Paso {currentStepId} de {steps?.length}
          </span>
          <span className="text-sm font-medium text-primary">
            {Math.round((currentStepId / steps?.length) * 100)}%
          </span>
        </div>
        <div className="w-full bg-muted rounded-full h-2">
          <div 
            className="bg-primary h-2 rounded-full transition-warm"
            style={{ width: `${(currentStepId / steps?.length) * 100}%` }}
          />
        </div>
        <div className="mt-2 text-center">
          <span className="text-base font-medium text-foreground">
            {steps?.find(step => step?.id === currentStepId)?.label}
          </span>
        </div>
      </div>
      {/* Desktop Progress Steps */}
      <div className="hidden sm:flex items-center justify-between max-w-3xl mx-auto">
        {steps?.map((step, index) => (
          <div key={step?.id} className="flex items-center">
            <div className="flex flex-col items-center">
              <div className={`
                w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold transition-warm
                ${isStepActive(step?.id) 
                  ? 'bg-primary text-primary-foreground shadow-warm-md scale-110' 
                  : isStepCompleted(step?.id)
                    ? 'bg-success text-success-foreground shadow-warm'
                    : 'bg-muted text-muted-foreground'
                }
              `}>
                {isStepCompleted(step?.id) ? (
                  <Icon name="Check" size={18} strokeWidth={2.5} />
                ) : (
                  step?.id
                )}
              </div>
              <span className={`
                mt-3 text-sm font-medium transition-warm
                ${isStepActive(step?.id) 
                  ? 'text-primary' 
                  : isStepCompleted(step?.id)
                    ? 'text-success' :'text-muted-foreground'
                }
              `}>
                {step?.label}
              </span>
            </div>
            {index < steps?.length - 1 && (
              <div className={`
                flex-1 h-0.5 mx-4 transition-warm
                ${isStepCompleted(step?.id + 1) 
                  ? 'bg-success' 
                  : isStepActive(step?.id)
                    ? 'bg-gradient-to-r from-primary to-muted' :'bg-border'
                }
              `} />
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProgressIndicator;