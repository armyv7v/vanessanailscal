import React from 'react';
import Icon from '../AppIcon';

const BookingSummary = ({ 
  selectedServices = [], 
  selectedDate, 
  selectedTime, 
  customerInfo = {},
  className = '' 
}) => {
  const formatPrice = (price) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(price);
  };

  const formatDate = (date) => {
    return date?.toLocaleDateString('es-ES', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (time) => {
    return time?.toLocaleTimeString('es-ES', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });
  };

  const formatDuration = (minutes) => {
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}min` : `${hours}h`;
  };

  const calculateTotals = () => {
    const subtotal = selectedServices?.reduce((sum, service) => sum + (service?.price || 0), 0);
    const tax = Math.round(subtotal * 0.19); // 19% IVA
    const total = subtotal + tax;
    
    return { subtotal, tax, total };
  };

  const { subtotal, tax, total } = calculateTotals();
  const totalDuration = selectedServices?.reduce((sum, service) => sum + (service?.duration || 0), 0);

  if (selectedServices?.length === 0) {
    return (
      <div className={`bg-card border border-border rounded-lg p-6 shadow-warm ${className}`}>
        <div className="text-center">
          <Icon name="ShoppingBag" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">
            Resumen de reserva
          </h3>
          <p className="text-muted-foreground">
            Selecciona servicios para ver el resumen
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-card border border-border rounded-lg overflow-hidden shadow-warm ${className}`}>
      {/* Header */}
      <div className="bg-primary/5 border-b border-border p-4">
        <h3 className="text-lg font-semibold text-foreground flex items-center">
          <Icon name="Calendar" size={20} className="mr-2 text-primary" />
          Resumen de reserva
        </h3>
      </div>

      {/* Selected Services */}
      <div className="p-4">
        <h4 className="font-semibold text-foreground mb-3 flex items-center">
          <Icon name="Scissors" size={16} className="mr-2 text-primary" />
          Servicios seleccionados ({selectedServices?.length})
        </h4>
        <div className="space-y-3 mb-4">
          {selectedServices?.map((service) => (
            <div key={service?.id} className="flex justify-between items-start">
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground line-clamp-2">
                  {service?.name}
                </p>
                <p className="text-sm text-muted-foreground">
                  {formatDuration(service?.duration)}
                </p>
              </div>
              <div className="text-right ml-3">
                <p className="font-semibold text-foreground">
                  {formatPrice(service?.price)}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Date & Time */}
      {(selectedDate || selectedTime) && (
        <div className="px-4 pb-4">
          <h4 className="font-semibold text-foreground mb-3 flex items-center">
            <Icon name="Clock" size={16} className="mr-2 text-primary" />
            Fecha y hora
          </h4>
          <div className="space-y-2">
            {selectedDate && (
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Fecha:</span>
                <span className="font-medium text-foreground">
                  {formatDate(selectedDate)}
                </span>
              </div>
            )}
            {selectedTime && (
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Hora:</span>
                <span className="font-medium text-foreground">
                  {formatTime(selectedTime)}
                </span>
              </div>
            )}
            {totalDuration > 0 && (
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Duración total:</span>
                <span className="font-medium text-foreground">
                  {formatDuration(totalDuration)}
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Customer Info */}
      {(customerInfo?.name || customerInfo?.email || customerInfo?.phone) && (
        <div className="px-4 pb-4">
          <h4 className="font-semibold text-foreground mb-3 flex items-center">
            <Icon name="User" size={16} className="mr-2 text-primary" />
            Información del cliente
          </h4>
          <div className="space-y-2">
            {customerInfo?.name && (
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Nombre:</span>
                <span className="font-medium text-foreground">
                  {customerInfo?.name}
                </span>
              </div>
            )}
            {customerInfo?.email && (
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Email:</span>
                <span className="font-medium text-foreground">
                  {customerInfo?.email}
                </span>
              </div>
            )}
            {customerInfo?.phone && (
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Teléfono:</span>
                <span className="font-medium text-foreground">
                  {customerInfo?.phone}
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Price Breakdown */}
      <div className="border-t border-border p-4">
        <h4 className="font-semibold text-foreground mb-3 flex items-center">
          <Icon name="Calculator" size={16} className="mr-2 text-primary" />
          Desglose de precios
        </h4>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Subtotal:</span>
            <span className="font-medium text-foreground">
              {formatPrice(subtotal)}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">IVA (19%):</span>
            <span className="font-medium text-foreground">
              {formatPrice(tax)}
            </span>
          </div>
          <div className="border-t border-border pt-2 mt-3">
            <div className="flex items-center justify-between">
              <span className="text-lg font-semibold text-foreground">Total:</span>
              <span className="text-xl font-bold text-primary">
                {formatPrice(total)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Additional Info */}
      <div className="bg-muted/30 p-4 text-center">
        <p className="text-xs text-muted-foreground">
          Los precios incluyen todos los impuestos aplicables
        </p>
      </div>
    </div>
  );
};

export default BookingSummary;